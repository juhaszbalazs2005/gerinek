﻿
namespace _4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbx_lista = new System.Windows.Forms.ListBox();
            this.cbx_osszes = new System.Windows.Forms.CheckBox();
            this.lbl_szoveg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbx_lista
            // 
            this.lbx_lista.FormattingEnabled = true;
            this.lbx_lista.Items.AddRange(new object[] {
            "Ez egy teszt szöveg",
            "Ez az előző alatt van",
            "Ez az előző után van",
            "Ez pedig az előző felett(csak vicceltem)"});
            this.lbx_lista.Location = new System.Drawing.Point(43, 41);
            this.lbx_lista.Name = "lbx_lista";
            this.lbx_lista.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lbx_lista.Size = new System.Drawing.Size(212, 329);
            this.lbx_lista.TabIndex = 0;
            this.lbx_lista.SelectedIndexChanged += new System.EventHandler(this.lbx_lista_SelectedIndexChanged);
            // 
            // cbx_osszes
            // 
            this.cbx_osszes.AutoSize = true;
            this.cbx_osszes.Location = new System.Drawing.Point(261, 182);
            this.cbx_osszes.Name = "cbx_osszes";
            this.cbx_osszes.Size = new System.Drawing.Size(129, 17);
            this.cbx_osszes.TabIndex = 1;
            this.cbx_osszes.Text = "Összes megjelenítése";
            this.cbx_osszes.UseVisualStyleBackColor = true;
            this.cbx_osszes.CheckedChanged += new System.EventHandler(this.cbx_osszes_CheckedChanged);
            // 
            // lbl_szoveg
            // 
            this.lbl_szoveg.AutoSize = true;
            this.lbl_szoveg.Location = new System.Drawing.Point(262, 206);
            this.lbl_szoveg.Name = "lbl_szoveg";
            this.lbl_szoveg.Size = new System.Drawing.Size(78, 13);
            this.lbl_szoveg.TabIndex = 2;
            this.lbl_szoveg.Text = "Elemek száma:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(416, 450);
            this.Controls.Add(this.lbl_szoveg);
            this.Controls.Add(this.cbx_osszes);
            this.Controls.Add(this.lbx_lista);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbx_lista;
        private System.Windows.Forms.CheckBox cbx_osszes;
        private System.Windows.Forms.Label lbl_szoveg;
    }
}


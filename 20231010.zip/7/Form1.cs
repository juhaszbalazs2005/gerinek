﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_openfile_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string szoveg = File.ReadAllText(openFileDialog1.FileName);
                int i = 0;
                int vanbenne = 0;
                while ((i = szoveg.IndexOf(tbx_szotoredek.Text, i)) != -1)
                {
                    i += tbx_szotoredek.Text.Length;
                    vanbenne++;
                }
                MessageBox.Show($"A fileban {vanbenne}x van benne az adott szótöredék");
            }
        }
    }
}

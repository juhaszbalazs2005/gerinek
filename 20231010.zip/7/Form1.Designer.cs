﻿namespace _7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_szotoredek = new System.Windows.Forms.TextBox();
            this.btn_openfile = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // tbx_szotoredek
            // 
            this.tbx_szotoredek.Location = new System.Drawing.Point(53, 32);
            this.tbx_szotoredek.Name = "tbx_szotoredek";
            this.tbx_szotoredek.Size = new System.Drawing.Size(100, 20);
            this.tbx_szotoredek.TabIndex = 0;
            // 
            // btn_openfile
            // 
            this.btn_openfile.Location = new System.Drawing.Point(64, 82);
            this.btn_openfile.Name = "btn_openfile";
            this.btn_openfile.Size = new System.Drawing.Size(75, 23);
            this.btn_openfile.TabIndex = 1;
            this.btn_openfile.Text = "Fájl megnyitása";
            this.btn_openfile.UseVisualStyleBackColor = true;
            this.btn_openfile.Click += new System.EventHandler(this.btn_openfile_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(208, 183);
            this.Controls.Add(this.btn_openfile);
            this.Controls.Add(this.tbx_szotoredek);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_szotoredek;
        private System.Windows.Forms.Button btn_openfile;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}


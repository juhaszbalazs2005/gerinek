﻿namespace _8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbx_nevek = new System.Windows.Forms.ListBox();
            this.btn_mentes = new System.Windows.Forms.Button();
            this.btn_load = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.btn_add = new System.Windows.Forms.Button();
            this.tbx_nev = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbx_nevek
            // 
            this.lbx_nevek.FormattingEnabled = true;
            this.lbx_nevek.Location = new System.Drawing.Point(45, 33);
            this.lbx_nevek.Name = "lbx_nevek";
            this.lbx_nevek.Size = new System.Drawing.Size(266, 199);
            this.lbx_nevek.TabIndex = 0;
            // 
            // btn_mentes
            // 
            this.btn_mentes.Location = new System.Drawing.Point(45, 257);
            this.btn_mentes.Name = "btn_mentes";
            this.btn_mentes.Size = new System.Drawing.Size(75, 23);
            this.btn_mentes.TabIndex = 1;
            this.btn_mentes.Text = "Mentés";
            this.btn_mentes.UseVisualStyleBackColor = true;
            this.btn_mentes.Click += new System.EventHandler(this.btn_mentes_Click);
            // 
            // btn_load
            // 
            this.btn_load.Location = new System.Drawing.Point(236, 257);
            this.btn_load.Name = "btn_load";
            this.btn_load.Size = new System.Drawing.Size(75, 23);
            this.btn_load.TabIndex = 2;
            this.btn_load.Text = "Betöltés";
            this.btn_load.UseVisualStyleBackColor = true;
            this.btn_load.Click += new System.EventHandler(this.btn_load_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(143, 257);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 3;
            this.btn_add.Text = "Hozzáad";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // tbx_nev
            // 
            this.tbx_nev.Location = new System.Drawing.Point(45, 299);
            this.tbx_nev.Name = "tbx_nev";
            this.tbx_nev.Size = new System.Drawing.Size(100, 20);
            this.tbx_nev.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 450);
            this.Controls.Add(this.tbx_nev);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_load);
            this.Controls.Add(this.btn_mentes);
            this.Controls.Add(this.lbx_nevek);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbx_nevek;
        private System.Windows.Forms.Button btn_mentes;
        private System.Windows.Forms.Button btn_load;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.TextBox tbx_nev;
    }
}


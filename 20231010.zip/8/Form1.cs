﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net.Http.Headers;

namespace _8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_mentes_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                List<string> nevek = new List<string>();
                foreach (var item in lbx_nevek.Items)
                {
                    nevek.Add(item.ToString());
                }
                File.WriteAllLines(saveFileDialog1.FileName, nevek);
            }
        }

        private void btn_load_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                List<string> nevek = new List<string>();
                foreach (var item in File.ReadAllLines(openFileDialog1.FileName))
                {
                    nevek.Add(item);
                }
                lbx_nevek.Items.Clear();
                foreach (var item in nevek)
                {
                    lbx_nevek.Items.Add(item);
                }
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            lbx_nevek.Items.Add(tbx_nev.Text);
        }
    }
}

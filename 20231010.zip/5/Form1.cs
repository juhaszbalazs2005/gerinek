﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cbx_lista_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (radio_betu.Checked)
            {
                if (cbx_lista.SelectedItem.ToString() == "Kék")
                {
                    this.ForeColor = Color.Blue;
                }
                else if (cbx_lista.SelectedItem.ToString() == "Zöld")
                {
                    this.ForeColor = Color.Green;
                }
                else if (cbx_lista.SelectedItem.ToString() == "Piros")
                {
                    this.ForeColor = Color.Red;
                }
                
            }
            else
            {
                if (cbx_lista.SelectedItem.ToString() == "Kék")
                {
                    this.BackColor = Color.Blue;
                }
                else if (cbx_lista.SelectedItem.ToString() == "Zöld")
                {
                    this.BackColor = Color.Green;
                }
                else if (cbx_lista.SelectedItem.ToString() == "Piros")
                {
                    this.BackColor = Color.Red;
                }
            }
        }
    }
}

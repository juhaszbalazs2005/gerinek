﻿
namespace _5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbx_lista = new System.Windows.Forms.ComboBox();
            this.radio_hatter = new System.Windows.Forms.RadioButton();
            this.radio_betu = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // cbx_lista
            // 
            this.cbx_lista.FormattingEnabled = true;
            this.cbx_lista.Items.AddRange(new object[] {
            "Zöld",
            "Piros",
            "Kék"});
            this.cbx_lista.Location = new System.Drawing.Point(106, 134);
            this.cbx_lista.Name = "cbx_lista";
            this.cbx_lista.Size = new System.Drawing.Size(121, 21);
            this.cbx_lista.TabIndex = 0;
            this.cbx_lista.SelectedIndexChanged += new System.EventHandler(this.cbx_lista_SelectedIndexChanged);
            // 
            // radio_hatter
            // 
            this.radio_hatter.AutoSize = true;
            this.radio_hatter.Location = new System.Drawing.Point(59, 209);
            this.radio_hatter.Name = "radio_hatter";
            this.radio_hatter.Size = new System.Drawing.Size(74, 17);
            this.radio_hatter.TabIndex = 1;
            this.radio_hatter.TabStop = true;
            this.radio_hatter.Text = "Háttérszín";
            this.radio_hatter.UseVisualStyleBackColor = true;
            // 
            // radio_betu
            // 
            this.radio_betu.AutoSize = true;
            this.radio_betu.Location = new System.Drawing.Point(175, 209);
            this.radio_betu.Name = "radio_betu";
            this.radio_betu.Size = new System.Drawing.Size(67, 17);
            this.radio_betu.TabIndex = 2;
            this.radio_betu.TabStop = true;
            this.radio_betu.Text = "Betüszín";
            this.radio_betu.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 450);
            this.Controls.Add(this.radio_betu);
            this.Controls.Add(this.radio_hatter);
            this.Controls.Add(this.cbx_lista);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbx_lista;
        private System.Windows.Forms.RadioButton radio_hatter;
        private System.Windows.Forms.RadioButton radio_betu;
    }
}


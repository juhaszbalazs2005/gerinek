﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rbn_novekvo_CheckedChanged(object sender, EventArgs e)
        {
            if (rbn_novekvo.Checked)
            {
                List<int> szamok = new List<int>();
                foreach (var item in listBox1.Items)
                {
                    szamok.Add(Convert.ToInt32(item));
                }
                szamok.Sort();
                listBox1.Items.Clear();
                foreach (var item in szamok)
                {
                    listBox1.Items.Add(item);
                }
            }
        }

        private void rbn_csokkeno_CheckedChanged(object sender, EventArgs e)
        {
            if (rbn_csokkeno.Checked)
            {
                List<int> szamok = new List<int>();
                foreach (var item in listBox1.Items)
                {
                    szamok.Add(Convert.ToInt32(item));
                }
                szamok.Sort();
                listBox1.Items.Clear();
                for (int i = 1; i < szamok.Count+1; i++)
                {
                    listBox1.Items.Add(szamok[szamok.Count - i]);
                }
            }
        }
    }
}

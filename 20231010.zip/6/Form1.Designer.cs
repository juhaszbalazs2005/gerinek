﻿namespace _6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.rbn_novekvo = new System.Windows.Forms.RadioButton();
            this.rbn_csokkeno = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "213",
            "653",
            "134",
            "3",
            "765",
            "2",
            "34",
            "785",
            "243",
            "6",
            "8654"});
            this.listBox1.Location = new System.Drawing.Point(26, 32);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(241, 290);
            this.listBox1.TabIndex = 0;
            // 
            // rbn_novekvo
            // 
            this.rbn_novekvo.AutoSize = true;
            this.rbn_novekvo.Location = new System.Drawing.Point(26, 353);
            this.rbn_novekvo.Name = "rbn_novekvo";
            this.rbn_novekvo.Size = new System.Drawing.Size(69, 17);
            this.rbn_novekvo.TabIndex = 1;
            this.rbn_novekvo.TabStop = true;
            this.rbn_novekvo.Text = "Növekvő";
            this.rbn_novekvo.UseVisualStyleBackColor = true;
            this.rbn_novekvo.CheckedChanged += new System.EventHandler(this.rbn_novekvo_CheckedChanged);
            // 
            // rbn_csokkeno
            // 
            this.rbn_csokkeno.AutoSize = true;
            this.rbn_csokkeno.Location = new System.Drawing.Point(194, 353);
            this.rbn_csokkeno.Name = "rbn_csokkeno";
            this.rbn_csokkeno.Size = new System.Drawing.Size(73, 17);
            this.rbn_csokkeno.TabIndex = 2;
            this.rbn_csokkeno.TabStop = true;
            this.rbn_csokkeno.Text = "Csökkenő";
            this.rbn_csokkeno.UseVisualStyleBackColor = true;
            this.rbn_csokkeno.CheckedChanged += new System.EventHandler(this.rbn_csokkeno_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(319, 450);
            this.Controls.Add(this.rbn_csokkeno);
            this.Controls.Add(this.rbn_novekvo);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.RadioButton rbn_novekvo;
        private System.Windows.Forms.RadioButton rbn_csokkeno;
    }
}


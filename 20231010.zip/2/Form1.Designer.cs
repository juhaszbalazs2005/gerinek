﻿
namespace _2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbx_lista = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_szamol = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbx_lista
            // 
            this.lbx_lista.FormattingEnabled = true;
            this.lbx_lista.Items.AddRange(new object[] {
            "4",
            "213",
            "6",
            "124",
            "5",
            "8",
            "324"});
            this.lbx_lista.Location = new System.Drawing.Point(25, 22);
            this.lbx_lista.Name = "lbx_lista";
            this.lbx_lista.Size = new System.Drawing.Size(110, 394);
            this.lbx_lista.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(166, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "A számok összege:";
            // 
            // btn_szamol
            // 
            this.btn_szamol.Location = new System.Drawing.Point(169, 52);
            this.btn_szamol.Name = "btn_szamol";
            this.btn_szamol.Size = new System.Drawing.Size(95, 32);
            this.btn_szamol.TabIndex = 2;
            this.btn_szamol.Text = "Számolás";
            this.btn_szamol.UseVisualStyleBackColor = true;
            this.btn_szamol.Click += new System.EventHandler(this.btn_szamol_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_szamol);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbx_lista);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbx_lista;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_szamol;
    }
}


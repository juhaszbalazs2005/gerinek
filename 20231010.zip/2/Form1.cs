﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_szamol_Click(object sender, EventArgs e)
        {
            double osszeg = 0;
            foreach (var item in lbx_lista.Items)
            {
                osszeg = osszeg + Convert.ToDouble(item);
            }
            label1.Text = osszeg.ToString();
        }
    }
}

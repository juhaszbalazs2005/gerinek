﻿
namespace _3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_szoveg = new System.Windows.Forms.TextBox();
            this.cbx_nagybetu = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // tbx_szoveg
            // 
            this.tbx_szoveg.Location = new System.Drawing.Point(34, 35);
            this.tbx_szoveg.Multiline = true;
            this.tbx_szoveg.Name = "tbx_szoveg";
            this.tbx_szoveg.Size = new System.Drawing.Size(351, 146);
            this.tbx_szoveg.TabIndex = 0;
            // 
            // cbx_nagybetu
            // 
            this.cbx_nagybetu.AutoSize = true;
            this.cbx_nagybetu.Location = new System.Drawing.Point(156, 221);
            this.cbx_nagybetu.Name = "cbx_nagybetu";
            this.cbx_nagybetu.Size = new System.Drawing.Size(88, 17);
            this.cbx_nagybetu.TabIndex = 1;
            this.cbx_nagybetu.Text = "Nagybetűssé";
            this.cbx_nagybetu.UseVisualStyleBackColor = true;
            this.cbx_nagybetu.CheckedChanged += new System.EventHandler(this.cbx_nagybetu_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(408, 450);
            this.Controls.Add(this.cbx_nagybetu);
            this.Controls.Add(this.tbx_szoveg);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_szoveg;
        private System.Windows.Forms.CheckBox cbx_nagybetu;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cbx_nagybetu_CheckedChanged(object sender, EventArgs e)
        {
            if (cbx_nagybetu.Checked == true)
            {
                tbx_szoveg.Text = tbx_szoveg.Text.ToUpper();
            }
            else
            {
                tbx_szoveg.Text = tbx_szoveg.Text.ToLower();
            }
        }
    }
}
